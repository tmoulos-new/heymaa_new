---
name: heymaa-admin-architecture
description: >-
  Supabase + FastAPI + React admin CMS patterns: soft delete (is_deleted),
  activity audit log, user_id on records, junction tables, server-side sort/pagination,
  x-token admin auth, SPA/API proxy bypass, SECURITY DEFINER RPCs, RLS. Use when
  building or extending admin backends, audit logs, CMS features, or when the user
  asks to follow HeyMaa architecture decisions in a new app.
---

# HeyMaa admin architecture

Reusable patterns from HeyMaa for **Supabase + FastAPI + React** admin CMS apps. Apply when implementing admin features in this repo or porting patterns to another project.

## When to use

- Adding admin CRUD, soft delete, restore, or trash views
- Building audit / activity log (before/after snapshots)
- Many-to-many via junction tables (e.g. entity ↔ regions)
- Admin tables with sortable headers and pagination
- Admin auth (`x-token`), dev proxy, or SPA refresh issues on `/admin/*`
- New Supabase migrations for content tables

## Non-negotiables

1. **Soft delete:** `is_deleted boolean NOT NULL DEFAULT false`; partial index `WHERE is_deleted = false`; never hard-delete from admin
2. **Creator:** `user_id uuid NOT NULL REFERENCES auth.users(id)` on admin-created rows; set from `verify_admin()`
3. **Audit:** Append-only `activity_log`; before/after JSON snapshots; include junction IDs in snapshots; log failures must not block mutations
4. **Junction M2M:** `{entity}_{related}` table, composite PK, replace-all sync on update
5. **List APIs:** Server sort (whitelisted columns) + `limit`/`offset` + `total`; default page size 10 for admin tables
6. **Admin auth:** JWT in `x-token`; password login via **separate** Supabase client — never `sign_out()` on service-role client after login
7. **SPA vs API:** HTML GET to admin UI paths must not proxy to FastAPI — update `ADMIN_UI_GET_PATHS` when adding routes
8. **Public reads:** `SECURITY DEFINER` RPCs or explicit filters; always exclude `is_deleted`

## Implementation workflow

When asked to add a new admin-managed entity:

1. **Migration:** table + `is_deleted` + `user_id` + indexes; separate RLS file if needed
2. **Backend:** list (`deleted_only`), create (set `user_id`), update, soft delete, restore; `_log_activity` on every mutation
3. **Snapshots:** strip computed fields; merge junction FKs into snapshot for diffs
4. **Admin UI:** `adminFetch`, show deleted toggle, restore action, creator name if listed
5. **Proxy:** add SPA route to `frontend/src/setupProxy.js` and `admin/vite.config.ts` bypass lists

## Quick checklist

**Database:** `is_deleted`, `user_id`, junction tables if M2M, `activity_log` + indexes

**Backend:** `verify_admin`, `_apply_deleted_filter`, `_log_activity`, whitelisted `sort_by`, public/RPC filters

**Frontend:** sortable headers, pagination, `diffSnapshots` for audit UI, proxy bypass for new tabs

## Full reference

For schemas, code snippets, API contracts, and file paths in HeyMaa, read [reference.md](reference.md).

Canonical copy in repo: `docs/ARCHITECTURE_DECISIONS.md` (keep in sync when patterns change).
